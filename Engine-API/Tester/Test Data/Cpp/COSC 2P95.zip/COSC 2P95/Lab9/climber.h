void* climb(void* unnecessary);
double calcHeight(double x, double y);
double fRand(double fMin, double fMax);
void interrupted(int sig);
void probe(int sig);
int menu();