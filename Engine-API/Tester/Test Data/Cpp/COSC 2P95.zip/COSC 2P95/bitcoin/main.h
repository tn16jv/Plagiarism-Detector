void* hashwork(void* unnecessary);
//void peek(int, sig);
void interrupted(int sig);
void genULong(unsigned long &nonce);
void printThirtyTwo(unsigned int word);
void printSixtyFour(unsigned long word);
unsigned int calcHash(unsigned long nonce);
int leadingZeroes(unsigned int values);
int menu();
