#include <iostream>
using namespace std;
struct PRecord {
	long time;
	string entry;
};
