#include <iostream>
#include <string>
#include "PriorityQueue.h"

int main(){
	{
		PriorityQueue<int,10> pq;
	}
}