#include <iostream>
#include <string>

int main() {
	int k;
	double d;
	k=3;
	d=2.0;
	std::cout<<d/k<<std::endl;
}
