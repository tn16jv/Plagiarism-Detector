#include <iostream>
#include <string>

using namespace std;

int main() {
	bool a,b;
	//a=true;
	a=false;
	b=true;
	if (a)
		if (b)
			cout<<"Yes, a and b"<<endl;
	else
		cout<<"Uh... help?"<<endl;
}
