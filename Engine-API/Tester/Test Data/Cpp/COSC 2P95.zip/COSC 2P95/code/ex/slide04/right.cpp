#include "right.h"

wisdom askTheRight() {
	wisdom w={"If anyone is ever taxed out of home ownership, the government is governmenting wrong."};
	return w;
}