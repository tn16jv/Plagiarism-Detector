#include "top.h"

wisdom askTheLeft();