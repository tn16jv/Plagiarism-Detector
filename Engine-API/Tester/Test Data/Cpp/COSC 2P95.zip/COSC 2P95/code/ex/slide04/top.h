#include <string>
struct wisdom {
	std::string msg;
};

wisdom askTheCentre();