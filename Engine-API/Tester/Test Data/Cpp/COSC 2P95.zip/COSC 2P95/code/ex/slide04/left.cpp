#include "left.h"

wisdom askTheLeft() {
	wisdom w={"It takes a village... to fight off super mutant attacks."};
	return w;
}