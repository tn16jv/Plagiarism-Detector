#include "top.h"

wisdom askTheRight();