#include <iostream>
#include "top.h"

wisdom askTheCentre() {
	wisdom w={"Yeah. Nobody actually wants to hear a middle-ground."};
	return w;
}