//Note that the function name's the same, but the signatures vary
int max(int a,int b);
double max(double a, double b);
