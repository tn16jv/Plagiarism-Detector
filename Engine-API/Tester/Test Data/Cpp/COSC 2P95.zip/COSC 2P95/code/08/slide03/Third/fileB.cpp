#include <string>
#include "fileB.h"

namespace Betta {
	std::string dealie() {
		return "B-Betta-dealie";
	}
}

namespace Friendo {
	std::string stuff() {
		return "B-Friendo-stuf";
	}
}
