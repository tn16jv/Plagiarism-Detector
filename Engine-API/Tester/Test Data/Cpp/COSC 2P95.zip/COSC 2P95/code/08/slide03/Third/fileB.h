#include <string>

namespace Betta {
	std::string dealie();
}

namespace Friendo {
	std::string stuff();
}
