#include <iostream>
#include "Raptor.h"

int main() {
	ornithology::Raptor toronto;
	toronto.sing();
	toronto.hunt();
}
