#include <iostream>
#include "Velociraptor.h"

int main() {
	paleontology::Velociraptor v;
	v.flap();
	v.confess();
}