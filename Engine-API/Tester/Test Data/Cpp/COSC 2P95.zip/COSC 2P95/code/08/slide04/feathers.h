//This file defines what it means to be feathered

namespace feathers {
	class Feathered {
	public:
		void flap();
		void balance();
		void writeOldTymeyLetters();
	};
}
