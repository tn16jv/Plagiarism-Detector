#include <iostream>

//Everything's the same as last time, but this time we're just providing the implementation right here:
int bebe() {
	return 73;
}

int main() {
	std::cout<<"Can we use our own bebe? "<<bebe()<<std::endl;
}
