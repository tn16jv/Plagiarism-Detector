#include <iostream>
#include "ornithology.h"
#include "Raptor.h"
//If I wanted, I could even include feathers! (For... uh... a raptor-pillow? Sure, why not)

int main() {
	ornithology::Raptor toronto;
	toronto.sing();
	toronto.hunt();
}
