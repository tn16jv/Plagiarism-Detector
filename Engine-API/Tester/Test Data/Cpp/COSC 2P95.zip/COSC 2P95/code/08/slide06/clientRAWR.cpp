#include <iostream>
#include "paleontology.h"
#include "Velociraptor.h"
#include "Archaeopteryx.h"

int main() {
	paleontology::Archaeopteryx a;
	a.sing();
	a.confess();
}