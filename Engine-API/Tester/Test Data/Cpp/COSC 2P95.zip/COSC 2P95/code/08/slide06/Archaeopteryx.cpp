#include <iostream>
#include "Archaeopteryx.h"
//Just here to ensure that we'll have an object file
