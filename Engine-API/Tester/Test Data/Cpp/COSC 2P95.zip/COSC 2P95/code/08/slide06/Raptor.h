#pragma once
#include "ornithology.h"
//No. Not the cool kind (yet).

namespace ornithology {
	class Raptor : public Bird{
	public:
		void hunt();
	};
}
