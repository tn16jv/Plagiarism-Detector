/*Paleontology library
 *Because dinosaurs are spiffy!
 */

namespace paleontology {
	class Dinosaur {
	public:
		void speakTheTruth();
		void confess();
	};
}
